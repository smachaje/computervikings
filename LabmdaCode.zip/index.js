/**
    Copyright 2014-2015 Amazon.com, Inc. or its affiliates. All Rights Reserved.

    Licensed under the Apache License, Version 2.0 (the "License"). You may not use this file except in compliance with the License. A copy of the License is located at

        http://aws.amazon.com/apache2.0/

    or in the "license" file accompanying this file. This file is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the specific language governing permissions and limitations under the License.
*/

/**
 * This simple sample has no external dependencies or session management, and shows the most basic
 * example of how to create a Lambda function for handling Alexa Skill requests.
 *
 * Examples:
 * One-shot model:
 *  User: "Alexa, ask Space Geek for a space fact"
 *  Alexa: "Here's your space fact: ..."
 */

/**
 * App ID for the skill
 */
var APP_ID = undefined;
//"amzn1.echo-sdk-ams.app.21bd6c10-71cf-4734-b97c-38abb3bef509";
//replace with "amzn1.echo-sdk-ams.app.[your-unique-value-here]";

/**
 * Array containing space facts.
 */
var SPACE_FACTS = [
	"Bluetooth technology, a low power and short range wireless communication, was named by the Swedish company Ericsson in honor of a Viking king Harald Bluetooth.",
	"Harald Bluetooth was a Viking king with terribly decayed teeth and that's where he got his name. He united quarelling Danish tribes and the wireless technology was to unite the same way wireless communication protocols.",
	"The Internet and the World Wide Web are different.  The Internet is a network, the web is a system of documents.  Oceans and rivers were like the Internet for Vikings.  The ships were like the world wide web documents.",
	"Learning about computers involves exploration. Initially, hacking at a computer simply meant trying different things out.  Vikings were the greatest explorers of all times.  They travelled from Sweden to England, Constantinople, Baghdad in Iraq, and North America.  Leif Eriksson arrived in America about 500 years before Christopher Columbus. That's the kind of explorer spirit that is required in mastering computers.",
	"The Viking long boats were a game changing technology innovation in 700 CE.  They could sail on rivers and oceans, which gave the Vikings a global access to people and resources.  Rivers, seas, lakes, and oceans were a network, just like the Internet today.",
	"The icon for the Bluetooth technology is a rune sign from the time of the Vikings. The sign is a bind rune merging two letters - the Younger Futhark runes letter (Hagall) or H, and runic letter (Bjarkan) or B. H and B were Harald’s initials.",
 	"Computer frustration is common. According to a study by British Association of Anger Management about 50% of people reacted to computer problems by either abusing colleagues, hitting the computer, screaming, shouting or hurling computer parts. Viking special forces, called Berserkers, would fight in a nearly uncontrollable, trance-like fury, while wearing no armor, only bear or wolf hides. Computers make us go berserk sometimes.", 
	"Phablet, similar to a phone and a tablet, is a device that puts together the features of a smartphone with a tablet.  Just as a Viking shield, the phablet is small enough to be carried anywhere, but large enough for important tasks.",
	"Solid-state drive is a storage device, like a hard drive.  However, it uses flash memory without moving parts.  Viking ships were built through clinker design to sustain physical force and shock of ocean waves like solid-state drives.",
	"Wiki is a Hawaiian expression for being quick.  Wiki Wiki means very quick and in 1995 Howard Cunningham created the first Wiki Wiki Web. Viking raid attacks were Wiki Wiki to avoid confrontation with defending armies.",
	"Wiki is a collaborative website that allows users to create, modify, or delete document content via the browser.  Vikings didn't write their stories down.  Their slaves in Iceland started written documents called Sagas. While a runic alphabet can be used for writing a document, that wasn’t their purpose, as the Norse culture was a spoken culture, or oral culture, transferred through the word of mouth. .",
	"Only about 10% of the world's currency is physical money, the rest only exists on computers. Vikings were often paid large amounts of coins to leave English shores, and even today more late Anglo-Saxon coins are found in Scandinavia than in Britain.",
	"Gamification is the use of game mechanics and experience design to digitally engage and motivate people to achieve their goals (Burke, 2014). Vikings played many games including drinking games with man and woman teams. Each team would drink, then boast, tell rhymes and insult the other team. The object was to see who could drink the most and remain articulate and witty. Gamification on tap.",
	"Gamification is the use of game design elements in non-gamecontexts (Deterding, 2011). For example, Road Vikings is a mobile service for young drivers that promotes good and safe driving in a rewarding and engaging way. Drivers earn Viking Plunder Points.",
	"ASCII is a 7 bit encoding scheme, which means it is a link between computer readable numbers and human readable pictures, or what we see as characters and numbers. The letter A in various fonts can be a very creative drawing.  ASCII stands for American Standard Code for Information Interchange and it is limited to 128 characters based on English alphabet. Runes were Viking characters.  Odin had discovered the runes as he hung himself on Yggdrasil, the world tree, for nine days. During this ordeal, Odin fasted and stared into the Well of Urd, where he perceived the runes.",
	"Open source software does not always mean free or no cost software. It just means that the source code is available. Vikings didn't write things down, which made trade secrets easier to keep secured.",
	"The first electronic computer ENIAC weighed more than 27 tons and took up 1800 square feet.  The largest Viking ship found was in Roskilde, Denmark.  This cargo ship was 121 feet long, it could carry 24 tons of load, and at 3 feet of draft it had the sail measuring 2,175 square feet. The sail was as big as ENIAC and the ship could almost sail with the computer onboard without sinking. ",
	"Around 50% of all Wikipedia vandalism is caught by a single computer program with more than 90% accuracy.  Vandals were a Germanic tribe with the name taken probably from a province in Uppland, Sweden.  They migrated from Scandinavia to an area known as Poland today before the Viking age, way back in 120 BC. Vandals successfully raided Rome in 455 CE.",
	"The password for the computer controls of nuclear tipped missiles of the U.S was 0 0 0 0 0 0 0 0, for eight years.  Passwords should have letters, numbers, and special characters of 8 positions of more.  A Viking map, called Vinland map, showing the shore of North America indicating that Vikings discovered America, included a rune writing riddle, like a password. The rune riddle increases the likelihood that the map is authentic.",
	"Three students from a school in Nevada installed keystroke loggers on their teachers' computers to intercept the teachers' usernames and passwords, and then charged other students up to $300 to hack in and increase their grades.  If you decide to break the law or academic code, be prepared for being punished like a captured Viking.  Well, let's just say that the English were very creative.",
	"Alan Turing is the father of computer science and artificial intelligence. He helped to break German Enigma cyphers. A great leader of the Viking culture was Ragnar Lothbrook.  Alan Turing and Ragnar Lothbrook were both visionaries and at great personal risk put their talents into use.",
	"'cup tsha' is an acronym for 'Completely Automated Public Turing test to tell Computers and Humans Apart'.  To submit a web form you may be asked to type in a word that is presented in a convoluted picture.  Odin, a main Viking god, who wondered around the Earth, was known to take on human forms like a shapeshifter.",
	"'No more woof' is a device to read a dog's mind.  It has been developed by the Nordic Society for Invention and Discovery, a small Scandinavian research lab.",
	"An eccentric inventor, Charles Babbage, designed the first computer in 1820s the Difference Engine that could achieve an 'absolute integrity of results'. Later, in 1830s, he designed a mechanical computer called the Analytical Engine. Doron Swade wrote an excellent biography of Babbage published by Viking press in 2001. ",
	"Stewardesses' is the longest word you can type with one hand on the modern computer keyboard.  Since Viking runes were carved into stone, Vikings preferred short words.  Writing that was lasting and brief, you might say laconic brevity, lapidary style, extremely compact, concise, and expressive or succinct.",
	"Author Mark Twain was one of the first people to purchase the early typewriter and is probably the first author to submit a typed manuscript to his publisher.  He was born two months prematurely and was not expected to survive.  In Viking tradition he would have been killed by his parents as a baby.",
	"Modern computer keyboard, called 'quarety' for the first 5 keys in the upper row, was patented by Latham Sholes in 1868 and designed to slow down the typist so the keys would not get stuck.",
	"A professor from Washington State University, Dr. John Dvorak, introduced a new keyboard design in the 1930s, but it was not widely accepted.  Most people preferred the more difficult and slower layout of the standard keyboard.",
	"Albert Einstein said: Games are the most elevated form of investigation.",
	"Alfred Nobel established a system of prizes in 1895.  They are awarded by the Swedish and Norwegian committees in recognition of academic, cultural, and scientific advances.  As a result, the Viking descendants are in charge of giving away the Nobel Peace Prize.",
	"Viking Press is an American publishing company founded in New York City on March 1, 1925. The firm's name and logo is a Viking ship drawn. It was meant to evoke the ideas of adventure, exploration, and enterprise implied by the word Viking.",
	"Linux, an open source operating system, was started in Scandinavia in Helsinki by Linus Torvalds.",
	"Testing your code by reasonable methods will help you find bugs, root problems, and separate errors.  King Olaf Tryggvason of Norway chose to accept Christianity to help the Vikings in world wide trading and politics.  To test that the new religion was working he sent Thangbrand to Iceland and 3 fires were planned.  One fire was blessed by the Catholic church, one by Viking priests, one left alone.  Then, a berserker named Otrygg was to walk through the Viking fire, then others.  After passing through the Viking fire the berserker was pained by unknown error.  He was killed and Christianity tested successfully.",
	"The kernel is a main program in an operating system, which talks to all the hardware devices.  The computer cannot run without the kernel working properly.  Kernel panic is a common error across many operating systems meaning that the core program encountered a crash.  A blue screen background accompanied the Windows 98 and XP kernel panic, and the error was named the Blue Screen of Death.  Ragnarok is the kind of kernel panic for the Viking culture.  Ragnarok was the end of the work in the Viking myths.  It meant that their gods and the dead would fight against another power and certainly loose.",
	"The Romans used to say that History is written by the victors... The history of Vikings was primarily written by Catholic monks, who were their victims and memorialized Vikings as savages. In medieval times violence was common in many cultures and only a minority of Vikings left Scandinavia to go raiding.  Today, the Internet allows many stories to be told, but we still recognize the power and bias of hearing only one side of any story.",
	"In the medieval times technology of Viking ships created a new job: the Viking raider.  Today too, technology creates many new jobs, like the White Hat Hacker, who is an ethical security explorer.",
	"In 793 AD the Vikings attacked from the sea shore the monastery in Lindisfarne, England. This radically changed the security assumption that the sea protects the flank of a town. It was not thought possible, wrote one cleric after the first attack, that such an inroad from the sea could be made.  Computer security specialists often encounter completely new vulnerabilities of varying risk.  Zero day vulnerability means that the vendor didn't expect hackers could ever exploit the software hole.",
	"We expect apps today to have a user friendly interface, to be easy to use. The Vikings didn't expect ease. Instead, the custom was for a father to place a sword in his new-born son's crib and say: I shall not leave you property to inherit. You have nothing but what you can acquire for yourself with this sword.",
	"After some years of raiding in England and France, the Vikings figured out a better business plan.  Instead of killing the farmers and craftsmen, the Vikings opted for collecting a tax, but it was really a ransom or extortion. They called it Danegeld, or Dane-Gold. The first time it was paid to Ragnar Lothbrok in Paris in 845 AD. Danegeld weighed six tons of silver and gold. Today, hackers also opt for extortion instead of data theft.  Recently, a hospital paid 13,000 dollars to have their own data unlocked.",
	"RAID is a computer technology, which stands for Redundant Array of Independent Disks.  This technique increases reliability by mirroring data to two drives (also called RAID 0) or speeding up storage by writing in parallel half of a file to each drive (also called RAID 1 or striping). The Vikings relied on the speed of their attack and a quick get away to avoid fighting soldiers.  Raids were supposed to be fast, like striping, and they were all very similar, like mirroring." 



];

/**
 * The AlexaSkill prototype and helper functions
 */
var AlexaSkill = require('./AlexaSkill');

/**
 * SpaceGeek is a child of AlexaSkill.
 * To read more about inheritance in JavaScript, see the link below.
 *
 * @see https://developer.mozilla.org/en-US/docs/Web/JavaScript/Introduction_to_Object-Oriented_JavaScript#Inheritance
 */
var SpaceGeek = function () {
    AlexaSkill.call(this, APP_ID);
};

// Extend AlexaSkill
SpaceGeek.prototype = Object.create(AlexaSkill.prototype);
SpaceGeek.prototype.constructor = SpaceGeek;

SpaceGeek.prototype.eventHandlers.onSessionStarted = function (sessionStartedRequest, session) {
    console.log("SpaceGeek onSessionStarted requestId: " + sessionStartedRequest.requestId
        + ", sessionId: " + session.sessionId);
    // any initialization logic goes here
};

SpaceGeek.prototype.eventHandlers.onLaunch = function (launchRequest, session, response) {
    console.log("SpaceGeek onLaunch requestId: " + launchRequest.requestId + ", sessionId: " + session.sessionId);
    handleNewFactRequest(response);
};

/**
 * Overridden to show that a subclass can override this function to teardown session state.
 */
SpaceGeek.prototype.eventHandlers.onSessionEnded = function (sessionEndedRequest, session) {
    console.log("SpaceGeek onSessionEnded requestId: " + sessionEndedRequest.requestId
        + ", sessionId: " + session.sessionId);
    // any cleanup logic goes here
};

SpaceGeek.prototype.intentHandlers = {
    "GetNewFactIntent": function (intent, session, response) {
        handleNewFactRequest(response);
    },


		"GetFullSagaIntent": function (intent, session, response) {
		handleFullSagaRequest(response);
		},
		"GetIndexFactIntent": function (intent, session, response) {
		handleIndexFactRequest(intent, response);
		},


    "AMAZON.HelpIntent": function (intent, session, response) {
        response.ask("You can ask: Alexa, ask Floki to tell me something, or, tell me a viking story, or, you can say exit... What can I help you with?", "What can I help you with?");
    },

    "AMAZON.StopIntent": function (intent, session, response) {
        var speechOutput = "See you in Valhalla!";
        response.tell(speechOutput);
    },

    "AMAZON.CancelIntent": function (intent, session, response) {
        var speechOutput = "See you in Valhalla!";
        response.tell(speechOutput);
    }
};

/**
 * Gets a random new fact from the list and returns to the user.
 */
function handleNewFactRequest(response) {
    // Get a random space fact from the space facts list
    var factIndex = Math.floor(Math.random() * SPACE_FACTS.length);
    var fact = SPACE_FACTS[factIndex];

    // Create speech output
    var speechOutput = "Here's your Computer Viking bit: " + fact;

    response.tellWithCard(speechOutput + " To hear all computer bits say: Alexa, ask Floki for full saga.", "Computer Vikings", speechOutput);
}

function handleIndexFactRequest(intent, response) {
    // Get a random space fact from the space facts list
	var factIndex = intent.slots.Index.value;

intMaxStories = 39;

if (factIndex > intMaxStories)
{ var speechOutput = "The number you selected, " + factIndex + " is too high.  I don't know this many stories yet.  Please say, Alexa, ask Floki to tell me story 1 through "+intMaxStories+". "; }
else {
        var fact = SPACE_FACTS[factIndex];

    // Create speech output
        var speechOutput = "Here's your Computer Viking bit number "+ factIndex +": " + fact;
}

        response.tellWithCard(speechOutput + " To hear all computer bits say: Alexa, ask Floki for full saga.", "Computer Vikings", speechOutput);
}

function handleFullSagaRequest(response) {

//only 8000 chars allowed, length of items unknown, so out of ... random start???

var intLeft = 0;
var intTotal = 0;
var speechOutput = "";
var sagaIntro = "";
var intMax = 21;


		intTotal = SPACE_FACTS.length;
		sagaIntro  = "Floki's saga book 1 with " + intMax + " stories. ";
		speechOutput = sagaIntro;

		var x = 0;
		for (x=0; x<intTotal; x++ )
		{
			intLeft = intMax - x - 1;

			var fact = SPACE_FACTS[x];

		if ( speechOutput.length > 7000 )
		{
			x = SPACE_FACTS.length;
			
		} else
		{
    			speechOutput = speechOutput + fact + "<break time=\"1s\" />Part " + (x+2) + ": " + "<break time=\"1s\" />";
		}




	}

	
	speechOutput = "<speak>" + speechOutput + " Ragnarok.</speak>";

	var speechOutputSSML = {
												speech: speechOutput,
												type: AlexaSkill.speechOutputType.SSML
 												};

	//response.tellWithCard(speechOutputSSML, "Computer Vikings", "Full saga of " + stopX + " stories. (" + speechOutput.length + ")");
	response.tellWithCard(speechOutputSSML, "Computer Vikings", sagaIntro + "For a random story out of " + intMaxStories + " say: Alexa, ask Floki to tell me something, or say Alexa, ask Floki to tell me story 30.");



}



// Create the handler that responds to the Alexa Request.
exports.handler = function (event, context) {
    // Create an instance of the SpaceGeek skill.
    var spaceGeek = new SpaceGeek();
    spaceGeek.execute(event, context);
};
